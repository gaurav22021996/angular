var express = require('express');
var app = express();
var crypto = require('crypto');

var bodyParser = require('body-parser');
app.use(bodyParser.json());
var urlencodedParser = bodyParser.urlencoded({ extended: false });

var fs = require("fs");
var path = require('path');
var multer = require('multer');
// app.use(multer({dest:''}));

var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database : "userFeeds_gaurav"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});
// Authenticate API
app.get("/auth", urlencodedParser, (req, res)=>{
    var email = req.query.user;
    var password = crypto.createHash('md5').update(req.query.pwd).digest("hex");

    con.query('SELECT * FROM users WHERE email = ?',[email], function (error, results, fields) {
        if (error) {
          res.send({
            "code":400,
            "status":0,
            "message":"error ocurred"
          })
        }else{
          if(results.length >0){
            if(results[0].pwd == password){
              res.send({
                "code":200,
                "status":1,
                "message":"login sucessfull"
                  });
            }
            else{
              res.send({
                "code":204,
                "status":0,
                "message":"Email and password does not match"
                  });
            }
          }
          else{
            res.send({
              "code":204,
              "status":0,
              "message":"Email does not exits"
                });
          }
        }
    });
});

app.get("/register", (req, res)=>{
    console.log(req.query.name);
    var users={
        "name":req.query.name,
        "pwd":crypto.createHash('md5').update(req.query.pwd).digest("hex"),
        "email":req.query.email
    }

    con.query('SELECT * FROM users WHERE email = ?',[req.query.email], function (error, results, fields) {
        if (error) {
          res.send({
            "code":400,
            "message":"error ocurred"
          })
        }else{
          if(results.length == 0){
            con.query('INSERT INTO users SET ?',users, function (error, results, fields) {
                if (error) {
                    console.log("error ocurred",error);
                    res.send({
                    "code":400,
                    "status":0,
                    "message":"error ocurred"
                    })
                }else{
                    res.send({
                    "code":200,
                    "status":1,
                    "message":"user registered sucessfully"
                        });
                }
            });
          }
          else{
            res.send({
                "code":212,
                "status":0,
                "message":"Email Already Exist"
                  });
          }
        }
    });
});

app.get('*', function (req, res) {
    res.send(JSON.stringify(
        {
            'message' : "Request not found",
            code : 400
        }
    ));
})
const http = app.listen(3200, ()=>{
    console.log("http server started at port 3000");
});